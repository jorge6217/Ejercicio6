package Ejercicio;

public class Song implements ICancion {
	private String titule;
	private String Artist;
	private String Album;
	private String Duration;
	private int ID;
	
	@Override
	public void setTitle(String _title) {
		this.titule = _title;
	}

	@Override
	public String getTitle() {
		return this.titule;
	}

	@Override
	public void setArtist(String _artist) {
		this.Artist = _artist;
	}

	@Override
	public String getArtist() {
		return this.Artist;
	}

	@Override
	public void setAlbum(String _album) {
		this.Album = _album;

	}

	@Override
	public String getAlbum() {
		return this.Album;
	}

	@Override
	public void setDuration(String _duration) {
		this.Duration = _duration;

	}

	@Override
	public String getDuration() {
		return this.Duration;
	}

	@Override
	public void setID(int _id) {
		this.ID = _id;
	}

	@Override
	public int getID() {
		// TODO Auto-generated method stub
		return this.ID;
	}

	/**
	 * Constructor de la cancion
	 * @param titule
	 * @param artist
	 * @param album
	 * @param duration
	 * @param iD
	 */
	public Song(String titule, String artist, String album, String duration, int iD) {
		super();
		this.titule = titule;
		Artist = artist;
		Album = album;
		Duration = duration;
		ID = iD;
	}
	
	
}
