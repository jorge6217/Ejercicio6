package Ejercicio;
/**
 * 
 */

/**
 * @author moises.alonso
 *
 */
public interface ICancion {

	public void setTitle(String _title);
	
	public String getTitle();
	
	public void setArtist(String _artist);
	
	public String getArtist();
	
	public void setAlbum(String _album);
	
	public String getAlbum();
	
	public void setDuration(String _duration);
	
	public String getDuration();
	
	public void setID(int _id);
	
	public int getID();
}
